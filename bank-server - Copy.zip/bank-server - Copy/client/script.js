"use strict";

const formCredentials = document.querySelector(".credentials__form-container");
const formSignup = document.querySelector(".signup__form");

const labelWelcome = document.querySelector(".welcome");
const labelDate = document.querySelector(".date");
const labelBalance = document.querySelector(".balance__value");
const labelSumIn = document.querySelector(".summary__value--in");
const labelSumOut = document.querySelector(".summary__value--out");
const labelSumInterest = document.querySelector(".summary__value--interest");

const containerApp = document.querySelector(".app");
const containerMovements = document.querySelector(".movements");

const btnLogin = document.querySelector(".login__btn");
const btnTransfer = document.querySelector(".form__btn--transfer");
const btnLoan = document.querySelector(".form__btn--loan");
const btnClose = document.querySelector(".form__btn--close");
const btnSort = document.querySelector(".btn--sort");
const btnLogout = document.querySelector(".form__btn--logout");
const btnSignup = document.querySelector(".signup__btn");
const btnCloseSignup = document.querySelector(".close-signup");
const btnRegister = document.querySelector(".register__btn");

const inputLoginUsername = document.querySelector(".login__input--user");
const inputLoginPin = document.querySelector(".login__input--pin");
const inputTransferTo = document.querySelector(".form__input--to");
const inputTransferAmount = document.querySelector(".form__input--amount");
const inputLoanAmount = document.querySelector(".form__input--loan-amount");
const inputCloseUsername = document.querySelector(".form__input--user");
const inputClosePin = document.querySelector(".form__input--pin");
const inputFullName = document.querySelector(".signup__input--name");
const inputUserNameSignup = document.querySelector(".signup__input--user");
const inputPinSignup = document.querySelector(".signup__input--pin");

const regStatus = document.querySelector("#registration_status");

const overlay = document.querySelector(".overlay");
const loginStatus = document.querySelector("#login_status");

let currentAccount;
let sorted = false;

/////////////////////////////////////////////////
// Testing Variables
const account1 = {
	owner: "John Smith",
	username: "js",
	movements: [200, 450, -400, 3000, -650, -130, 70, 1300],
	interestRate: 1.2, // %
	pin: 1111,
};

const account2 = {
	owner: "Saron Yitbarek",
	username: "sy",
	movements: [5000, 3400, -150, -790, -3210, -1000, 8500, -30],
	interestRate: 1.5,
	pin: 2222,
};
let accounts = {};

//SignUp Script
const openModal = function (e) {
	e.preventDefault();
	formSignup.classList.remove("hidden");
	overlay.classList.remove("hidden");
};

const closeModal = function (e) {
	e.preventDefault();
	formSignup.classList.add("hidden");
	overlay.classList.add("hidden");
};

btnSignup.addEventListener("click", openModal);
btnCloseSignup.addEventListener("click", closeModal);
overlay.addEventListener("click", closeModal);

document.addEventListener("keydown", function (e) {
	if (e.key === "Escape" && !formSignup.classList.contains("hidden")) {
		closeModal(e);
	}
});

btnRegister.addEventListener("click", async function (e) {
	e.preventDefault();
	try {
		const response = await fetch("http://localhost:5000/api/signup", {
			method: "POST",
			mode: "cors",
			body: JSON.stringify({
				fullName: inputFullName.value,
				userName: inputUserNameSignup.value,
				pin: +inputPinSignup.value,
			}), // string or object
			headers: {
				"Content-Type": "application/json",
			},
		});
		const data = await response.json();
		if (data.success) {
			alert(
				`Congrats ${inputFullName.value}. You are now a memeber of Bank of HiLCoE`
			);
			closeModal(e);
		} else {
			regStatus.classList.remove("hidden");
		}
	} catch (e) {
		regStatus.classList.remove("hidden");
	}
	/*
	if (!accounts.find((acc) => acc.username === inputUserNameSignup.value)) {
		accounts.push({
			owner: inputFullName.value,
			username: inputUserNameSignup.value,
			movements: [100],
			interestRate: 1,
			pin: +inputPinSignup.value,
		});
		alert(
			`Congrats ${inputFullName.value}. You are now a memeber of Bank of HiLCoE`
		);
		closeModal(e);
	} else regStatus.classList.remove("hidden");*/
});

/////////////////////////////////////////////////
// Main App Functions
const displayMovements = function (movements, sort = false) {
	containerMovements.innerHTML = "";
	console.log(movements);
	const movs = sort ? movements.slice().sort((a, b) => a - b) : movements;
	movs.forEach(function (mov, i) {
		const type = mov > 0 ? "deposit" : "withdrawal";

		const html = `
      <div class="movements__row">
        <div class="movements__type movements__type--${type}">${
			i + 1
		} ${type}</div>
        <div class="movements__value">${mov}$</div>
      </div>
    `;

		containerMovements.insertAdjacentHTML("afterbegin", html);
	});
};

const calcDisplayBalance = function (acc) {
	labelBalance.textContent = `${acc.accountBalance}$`;
};

const calcDisplaySummary = function (acc) {
	const incomes = acc.movements
		.filter((mov) => mov > 0)
		.reduce((acc, mov) => acc + mov, 0);
	labelSumIn.textContent = `${incomes}$`;

	const out = acc.movements
		.filter((mov) => mov < 0)
		.reduce((acc, mov) => acc + mov, 0);
	labelSumOut.textContent = `${Math.abs(out)}$`;

	const interest = acc.movements
		.filter((mov) => mov > 0)
		.map((deposit) => (deposit * acc.interestRate) / 100)
		.filter((int) => {
			return int >= 1;
		})
		.reduce((acc, int) => acc + int, 0);
	labelSumInterest.textContent = `${interest}$`;
};

const updateUI = function (acc) {
	displayMovements(acc.movements);
	calcDisplayBalance(acc);
	calcDisplaySummary(acc);
	labelDate.textContent = `${new Date().toLocaleString("en-US")}`;
};

btnLogin.addEventListener("click", async function (e) {
	e.preventDefault();
	try {
		const response = await fetch("http://localhost:5000/api/login", {
			method: "PUT",
			mode: "cors",
			body: JSON.stringify({
				userName: inputLoginUsername.value,
				pin: Number(inputLoginPin.value),
			}), // string or object
			headers: {
				"Content-Type": "application/json",
			},
		});
		const data = await response.json();
		if (data.success) {
			currentAccount = data.user;
			console.log(data, `Welcome back, ${data.user.fullName.split(" ")[0]}`);
			labelWelcome.textContent = `Welcome back, ${
				data.user.fullName.split(" ")[0]
			}`;
			containerApp.classList.remove("hidden");
			formCredentials.classList.add("hidden");

			// Clear input fields
			inputLoginUsername.value = inputLoginPin.value = "";
			inputLoginPin.blur();

			// Update UI
			console.log(data);
			updateUI(data.user);
		} else {
			loginStatus.classList.remove("hidden");
		}
	} catch (err) {
		console.log(err);
		loginStatus.classList.remove("hidden");
	}
	/*
	currentAccount = accounts.find(
		(acc) => acc.username === inputLoginUsername.value
	);

	if (currentAccount?.pin === Number(inputLoginPin.value)) {
		// Display UI and message
		labelWelcome.textContent = `Welcome back, ${
			currentAccount.owner.split(" ")[0]
		}`;
		containerApp.classList.remove("hidden");
		formCredentials.classList.add("hidden");

		// Clear input fields
		inputLoginUsername.value = inputLoginPin.value = "";
		inputLoginPin.blur();

		// Update UI
		updateUI(currentAccount);
	} else {
		loginStatus.classList.remove("hidden");
	}*/
});

const logout = function (e) {
	e.preventDefault();
	currentAccount = undefined;
	containerApp.classList.add("hidden");
	formCredentials.classList.remove("hidden");
	labelWelcome.textContent =
		"Welcome to Bank of HiLCoE - Log in to get started";
};

btnLogout.addEventListener("click", logout);

btnTransfer.addEventListener("click", async function (e) {
	e.preventDefault();
	const amount = Number(inputTransferAmount.value);
	const toAccount = inputTransferTo.value;
	inputTransferAmount.value = inputTransferTo.value = "";

	if (
		amount > 0 &&
		currentAccount.accountBalance >= amount &&
		currentAccount.userName !== toAccount
	) {
		const response = await fetch("http://localhost:5000/api/transferMoney", {
			method: "PUT",
			mode: "cors",
			body: JSON.stringify({
				amount,
				toAccount,
				fromAccount: currentAccount.userName,
			}), // string or object
			headers: {
				"Content-Type": "application/json",
			},
		});
		const data = await response.json();
		if (data.success) {
			currentAccount.movements.push(-amount);
			currentAccount.accountBalance = currentAccount.accountBalance - amount;
			// Update UI
			updateUI(currentAccount);
		}
	}
});

btnLoan.addEventListener("click", async function (e) {
	e.preventDefault();
	const amount = Math.floor(+inputLoanAmount.value);

	if (
		currentAccount.movements.some((mov) => mov >= amount / 10) &&
		amount > 0
	) {
		currentAccount.movements.push(amount);
		const response = await fetch("http://localhost:5000/api/requestLoan", {
			method: "PUT",
			mode: "cors",
			body: JSON.stringify({
				amount,
				fromAccount: currentAccount.userName,
			}), // string or object
			headers: {
				"Content-Type": "application/json",
			},
		});
		const data = await response.json();
		if (data.success) {
			currentAccount.accountBalance = currentAccount.accountBalance + amount;
			updateUI(currentAccount);
		}
	}
	inputLoanAmount.value = "";
});

btnClose.addEventListener("click", async function (e) {
	e.preventDefault();

	if (
		inputCloseUsername.value === currentAccount.username &&
		Number(inputClosePin.value) === currentAccount.pin
	) {
		const response = await fetch("http://localhost:5000/api/closeAccount", {
			method: "PUT",
			mode: "cors",
			body: JSON.stringify({
				userName: currentAccount.userName,
			}), // string or object
			headers: {
				"Content-Type": "application/json",
			},
		});
		const data = await response.json();
		if (data.success) {
			containerApp.classList.add("hidden");
			formCredentials.classList.remove("hidden");
			logout(e);
		}
	}

	inputCloseUsername.value = inputClosePin.value = "";
});

btnSort.addEventListener("click", function (e) {
	e.preventDefault();
	displayMovements(currentAccount.movements, !sorted);
	sorted = !sorted;
});
