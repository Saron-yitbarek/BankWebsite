const User = require("../models/User");

const signup = async (req, res) => {
	try {
		const user = new User(req.body);
		const result = await user.save();
		res.status(200).send({ success: true });
	} catch (err) {
		console.error(err);
		res.status(400).send(err);
	}
};

const login = async (req, res) => {
	try {
		if (!req.body.userName || !req.body.pin) {
			return res.status(400).send("Invalid Body");
		}
		const user = await User.findOne({
			userName: req.body.userName,
			pin: req.body.pin,
			isActive: true,
		});
		if (!user) {
			return res.status(400).send("Invalid Login Details");
		}
		res.status(200).send({ success: true, user });
	} catch (err) {
		console.error(err);
		res.status(400).send(err);
	}
};

const closeAccount = async (req, res) => {
	try {
		if (!req.body.userName) {
			return res.status(400).send("Invalid Body");
		}
		const user = await User.updateOne(
			{ userName: req.body.userName },
			{ $set: { isActive: false } }
		);
		if (!user || user.modifiedCount <= 0) {
			return res.status(400).send("Invalid user name");
		}
		res.status(200).send({ success: true });
	} catch (err) {
		console.error(err);
		res.status(400).send(err);
	}
};

module.exports = {
	signup,
	login,
	closeAccount,
};
