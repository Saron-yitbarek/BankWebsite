const User = require("../models/User");

const transferMoney = async (req, res) => {
	try {
		if (!req.body.toAccount || !req.body.fromAccount || !req.body.amount) {
			return res.status(400).send("Invalid Data");
		}
		req.body.amount = Number(req.body.amount);
		const toUser = await User.updateOne(
			{ userName: req.body.toAccount },
			{
				$inc: { accountBalance: req.body.amount, inAmount: req.body.amount },
				$push: { movements: req.body.amount },
			}
		);
		console.log("toUser", toUser);
		if (!toUser || toUser.modifiedCount <= 0) {
			return res.status(400).send("Invalid to user name");
		}
		const fromUser = await User.updateOne(
			{ userName: req.body.fromAccount },
			{
				$inc: { accountBalance: -req.body.amount, outAmount: req.body.amount },
				$push: { movements: -req.body.amount },
			}
		);
		if (!fromUser || fromUser.modifiedCount <= 0) {
			return res.status(400).send("Invalid from user name");
		}
		res.status(200).send({ success: true });
	} catch (err) {
		console.error(err);
		res.status(400).send(err);
	}
};

const requestLoan = async (req, res) => {
	try {
		if (!req.body.fromAccount || !req.body.amount) {
			return res.status(400).send("Invalid Data");
		}
		req.body.amount = Number(req.body.amount);
		const fromUser = await User.updateOne(
			{ userName: req.body.fromAccount },
			{
				$inc: { accountBalance: req.body.amount, inAmount: req.body.amount },
				$push: { movements: req.body.amount },
			}
		);
		if (!fromUser || fromUser.modifiedCount <= 0) {
			return res.status(400).send("Invalid user name");
		}
		res.status(200).send({ success: true });
	} catch (err) {
		console.error(err);
		res.status(400).send(err);
	}
};

module.exports = {
	transferMoney,
	requestLoan,
};
