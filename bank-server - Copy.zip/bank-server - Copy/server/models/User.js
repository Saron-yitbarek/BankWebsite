const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const userSchema = new Schema({
  fullName: { type: String, required: true},
  userName: { type: String, required: true, unique: true },
  pin: { type: Number, required: true},
  isActive: { type:Boolean, default: true},
  accountBalance: { type: Number, default: 100},
  inAmount: { type: Number, default: 100},
  outAmount: { type: Number, default: 0},
  movements: {type: Array, default: [100]},
});

const userModel = mongoose.model('User', userSchema);

module.exports = userModel;