const express = require("express")
const router = express.Router()

const operationsController = require('../controllers/operations')

router.put('/transferMoney', operationsController.transferMoney);
router.put('/requestLoan', operationsController.requestLoan);

module.exports = router